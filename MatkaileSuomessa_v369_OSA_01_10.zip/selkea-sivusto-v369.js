/* v369: yksi yhteinen navigointi, sisällöt ja matkamuistot säilyttäen. */
(() => {
 'use strict';
 const root = new URL('.', document.currentScript.src);
 const file = decodeURIComponent(location.pathname.split('/').pop() || 'index.html').toLowerCase();
 const items = [
  ['index.html','Koti','home'],['maakunnat.html','Paikkakunnat','map'],
  ['leirintaalueet.html','Yöpymispaikat','stay'],['pysahdy-matkalla.html','Pysähdy matkalla','sign'],
  ['reittisuunnittelu.html','Suunnittele reitti','route'],['paivakirja.html','Omat matkat','book']
 ];
 const paths = {
  home:'<path d="m3 11 9-8 9 8v10h-6v-7H9v7H3Z"/>',
  map:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z"/><path d="M9 3v15m6-12v15"/>',
  stay:'<path d="M3 17V6h13l5 6v5H3Zm0 0v3h3m4 0h5m4 0h2v-3M7 9h5v5H7Zm9-3v6h5"/><circle cx="8" cy="20" r="2"/><circle cx="17" cy="20" r="2"/>',
  sign:'<path d="M12 2v20M4 5h14l3 3-3 3H4Zm16 9H6l-3 3 3 3h14Z"/>',
  route:'<circle cx="5" cy="4" r="2"/><circle cx="19" cy="20" r="2"/><path d="M7 4h7a4 4 0 0 1 0 8h-4a4 4 0 0 0 0 8h7"/>',
  book:'<path d="M12 6C9 4 6 4 3 5v15c3-1 6-1 9 1 3-2 6-2 9-1V5c-3-1-6-1-9 1Zm0 0v15"/>'
 };
 const legacy = 'nav.foot,.bottomnav,.season-bottom-nav-v267,.tips-bottom,.ms353-masthead,#ms339-desktop-header,.ms339-end-links,header.site-header,header.msv-header,nav.site-nav,nav.bottom-nav,nav.ms301-nav,nav.ms302-nav,nav.ms303-nav,nav.ms304-nav,nav.ms322-bottom,.mobile-bottom,.footnav,.lap281-footnav,.ms334-footer,.ms337-bottom,.ms339-home-features';
 function icon(key){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+paths[key]+'</svg>'}
 function link(item){
  const [url,label,key]=item, a=document.createElement('a');a.href=new URL(url,root).href;
  const i=document.createElement('span');i.className='ms369-icon';i.innerHTML=icon(key);
  const text=document.createElement('span');text.textContent=label;a.append(i,text);
  if(file===url || (url==='maakunnat.html' && (file==='kunnat.html'||document.querySelector('.facts,.ms334-facts,.lap282-facts'))) || (url==='leirintaalueet.html'&&file==='matkaparkit.html'))a.setAttribute('aria-current','page');
  return a;
 }
 function cleanup(){
  document.querySelectorAll(legacy).forEach(n=>n.remove());
  // Only repeated global navigation is removed; in-page tabs and filters remain.
  document.querySelectorAll('nav:not(.ms369-desktop):not(.ms369-mobile)').forEach(n=>{
   const urls=new Set([...n.querySelectorAll('a[href]')].map(a=>new URL(a.href).pathname.split('/').pop()));
   if(items.filter(([u])=>urls.has(u)).length>=3)n.remove();
  });
 }
 function init(){
  document.body.classList.add('ms369-clear');cleanup();
  if(document.getElementById('ms369-header'))return;
  const content=document.querySelector('main')||document.querySelector('.app');
  if(content){content.classList.add('ms369-content');if(!content.id)content.id='ms369-content';}
  const skip=document.querySelector('.ms353-skip')||document.createElement('a');
  skip.className='ms369-skip';skip.textContent='Siirry sisältöön';skip.href='#'+(content?.id||'ms369-content');document.body.prepend(skip);
  const header=document.createElement('header');header.id='ms369-header';
  const inner=document.createElement('div');inner.className='ms369-header-inner';
  const brand=document.createElement('a');brand.className='ms369-brand';brand.href=new URL('index.html',root).href;
  brand.innerHTML='<span class="ms369-brand-icon"><svg viewBox="0 0 60 48" aria-hidden="true"><path d="M4 33 17 11l8 13 7-10 13 19H4Z" fill="#5b9f76"/><path d="m23 32 13-24 14 24H23Z" fill="#16543e"/><path d="m44 31 8-15 6 15H44Z" fill="#337458"/><path d="M3 39c17-8 34 8 54 0" fill="none" stroke="#1689b5" stroke-linecap="round" stroke-width="4"/></svg></span><span><strong>Matkaile Suomessa</strong><small>Vapaus kulkea · Ilo löytää</small></span>';
  const desktop=document.createElement('nav');desktop.className='ms369-desktop';desktop.setAttribute('aria-label','Päävalikko');items.forEach(item=>desktop.append(link(item)));
  inner.append(brand,desktop);header.append(inner);skip.after(header);
  const mobile=document.createElement('nav');mobile.className='ms369-mobile';mobile.setAttribute('aria-label','Päävalikko');
  [items[0],items[1],items[3],items[5]].forEach(item=>mobile.append(link(item)));document.body.append(mobile);
  // Keep one contextual return link, without repeating the current page title.
  const crumb=document.querySelector('.ms302-crumb');
  if(crumb){const links=[...crumb.querySelectorAll('a')];const back=links.at(-1);if(back){back.textContent='← '+back.textContent.replace(/^[←\s]+/,'');crumb.replaceChildren(back);}else crumb.remove();
   content?.querySelectorAll(':scope > a').forEach(a=>{if(a.href===back?.href)a.remove()});}
  const observer=new MutationObserver(records=>{if(records.some(r=>[...r.addedNodes].some(n=>n.nodeType===1&&(n.matches(legacy)||n.querySelector(legacy)))))cleanup()});
  observer.observe(document.body,{childList:true});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
 window.addEventListener('pageshow',()=>{cleanup()});
})();
